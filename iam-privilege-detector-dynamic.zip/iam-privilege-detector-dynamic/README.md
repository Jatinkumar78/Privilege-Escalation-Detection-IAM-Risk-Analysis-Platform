# IAM Privilege Escalation Detector (Dynamic + Hackathon Ready)

## What this solves (matches deliverables)
- Ingests dataset: Users, Roles, Permissions, Role inheritance/trust
- Identifies: Over-privileged accounts, Conflicting roles/permissions (SoD), Privilege escalation paths
- Outputs structured risk report: Escalation chain, severity, recommended remediation, MITRE mapping
- Demonstrates: Permission modelling + graph traversal (shortest path) + clear explanations

## Run
```bash
python -m venv venv
# Windows: venv\Scripts\activate
# Mac/Linux: source venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open:
- Dashboard: http://127.0.0.1:5000
- Graph: http://127.0.0.1:5000/graph
- Playbook: http://127.0.0.1:5000/playbook

## Upload JSON
Use the Upload button on the dashboard (top-right). The header and results update dynamically.

Schema:
```json
{
  "users":[{"name":"alice","roles":["support_staff"]}],
  "roles":{
    "support_staff":{"permissions":["view_tickets"],"inherits":["group_editor"]},
    "group_editor":{"permissions":["modify_groups"],"inherits":[]}
  }
}
```
