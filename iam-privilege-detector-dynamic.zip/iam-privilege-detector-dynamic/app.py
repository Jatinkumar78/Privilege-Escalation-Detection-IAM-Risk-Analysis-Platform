from flask import Flask, render_template, request, redirect, url_for, flash, session
import json
import os
import networkx as nx
from werkzeug.utils import secure_filename
from datetime import datetime
import uuid

app = Flask(__name__)
app.secret_key = "dev-secret-change-me"  # change for production

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_DATA_FILE = os.path.join(APP_DIR, "iam_data.json")
UPLOAD_DIR = os.path.join(APP_DIR, "uploads")
MITRE_MAP_FILE = os.path.join(APP_DIR, "mitre_map.json")

os.makedirs(UPLOAD_DIR, exist_ok=True)

TARGET_ROLE = "admin"

# Separation-of-duties examples (edit for your dataset)
CONFLICT_ROLE_PAIRS = [
    ("identity_manager", "security_auditor"),
    ("role_assigner", "security_auditor"),
]
CONFLICT_PERMISSION_PAIRS = [
    ("assign_roles", "audit_roles"),
    ("modify_groups", "audit_roles"),
    ("reset_passwords", "audit_roles"),
]


def load_mitre_map():
    try:
        with open(MITRE_MAP_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def get_current_data_file():
    path = session.get("current_data_file")
    if path and os.path.isfile(path):
        return path
    return DEFAULT_DATA_FILE


def load_data(path=None):
    path = path or get_current_data_file()
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def validate_dataset(data):
    if not isinstance(data, dict):
        return False, "Dataset must be a JSON object."
    if "users" not in data or "roles" not in data:
        return False, "Dataset must include 'users' and 'roles'."
    if not isinstance(data["users"], list) or not isinstance(data["roles"], dict):
        return False, "'users' must be a list and 'roles' must be an object."

    for u in data["users"]:
        if "name" not in u or "roles" not in u:
            return False, "Each user must have 'name' and 'roles'."
        if not isinstance(u["roles"], list):
            return False, "Each user's 'roles' must be a list."

    for role, details in data["roles"].items():
        if "permissions" not in details or "inherits" not in details:
            return False, f"Role '{role}' must include 'permissions' and 'inherits'."
        if not isinstance(details["permissions"], list) or not isinstance(details["inherits"], list):
            return False, f"Role '{role}': 'permissions' and 'inherits' must be lists."

    return True, ""


def build_role_graph(data):
    """Edge: role -> inherited_role"""
    G = nx.DiGraph()
    for role_name in data["roles"].keys():
        G.add_node(role_name)
    for role_name, details in data["roles"].items():
        for inherited in details.get("inherits", []):
            G.add_edge(role_name, inherited)
    return G


def risk_severity(path_len_nodes: int) -> str:
    if path_len_nodes <= 2:
        return "Critical"
    if path_len_nodes == 3:
        return "High"
    if path_len_nodes == 4:
        return "Medium"
    return "Low"


def get_all_effective_roles(G, start_role):
    reachable = set(nx.descendants(G, start_role))
    reachable.add(start_role)
    return reachable


def compute_effective_permissions(data, roles_set):
    perms = set()
    for r in roles_set:
        perms |= set(data["roles"].get(r, {}).get("permissions", []))
    return perms


def mitre_tags_for_permissions(mitre_map, permissions):
    tags = []
    for p in sorted(permissions):
        if p in mitre_map:
            tags.append({
                "permission": p,
                "technique": mitre_map[p].get("technique", ""),
                "id": mitre_map[p].get("id", ""),
                "tactic": mitre_map[p].get("tactic", ""),
                "note": mitre_map[p].get("note", "")
            })
    return tags


def find_escalation_paths(data, G, mitre_map):
    findings = []
    for user in data["users"]:
        user_name = user.get("name", "unknown_user")
        for start_role in user.get("roles", []):
            if start_role not in G.nodes:
                continue
            if nx.has_path(G, start_role, TARGET_ROLE):
                path = nx.shortest_path(G, start_role, TARGET_ROLE)
                severity = risk_severity(len(path))

                effective_roles = get_all_effective_roles(G, start_role)
                eff_perms = compute_effective_permissions(data, effective_roles)

                findings.append({
                    "user": user_name,
                    "start_role": start_role,
                    "target_role": TARGET_ROLE,
                    "path_text": " → ".join(path),
                    "steps": len(path) - 1,
                    "severity": severity,
                    "mitre": mitre_tags_for_permissions(mitre_map, eff_perms),
                    "recommendation": "Remove unsafe inheritance, restrict role assignment, enforce least privilege and approvals."
                })
    return findings


def find_overprivileged_users(data, G, mitre_map):
    risky_permissions = {"assign_roles", "modify_groups", "reset_passwords"}
    overprivileged = []

    for user in data["users"]:
        user_name = user.get("name", "unknown_user")
        effective_roles = set()
        for role in user.get("roles", []):
            if role in data["roles"]:
                effective_roles |= get_all_effective_roles(G, role)

        effective_permissions = compute_effective_permissions(data, effective_roles)

        flags = []
        if TARGET_ROLE in effective_roles:
            flags.append("Has admin access (directly or via inheritance)")
        dangerous = effective_permissions.intersection(risky_permissions)
        if dangerous:
            flags.append("Risky permissions: " + ", ".join(sorted(dangerous)))

        if flags:
            overprivileged.append({
                "user": user_name,
                "effective_roles": ", ".join(sorted(effective_roles)),
                "effective_permissions": ", ".join(sorted(effective_permissions)),
                "mitre": mitre_tags_for_permissions(mitre_map, effective_permissions),
                "flags": flags
            })
    return overprivileged


def find_conflicts(data, G):
    conflicts = []
    for user in data["users"]:
        user_name = user.get("name", "unknown_user")
        eff_roles = set()
        for role in user.get("roles", []):
            if role in data["roles"]:
                eff_roles |= get_all_effective_roles(G, role)
        eff_perms = compute_effective_permissions(data, eff_roles)

        found = []
        for a, b in CONFLICT_ROLE_PAIRS:
            if a in eff_roles and b in eff_roles:
                found.append(f"Conflicting roles: {a} + {b}")
        for p, q in CONFLICT_PERMISSION_PAIRS:
            if p in eff_perms and q in eff_perms:
                found.append(f"Conflicting permissions: {p} + {q}")

        if found:
            conflicts.append({
                "user": user_name,
                "effective_roles": ", ".join(sorted(eff_roles)),
                "effective_permissions": ", ".join(sorted(eff_perms)),
                "conflicts": found
            })
    return conflicts


def build_vis_graph_payload(data):
    nodes, edges = [], []

    for role, details in data["roles"].items():
        nodes.append({
            "id": f"role:{role}",
            "label": role,
            "group": "role",
            "title": f"Role: {role}\nPermissions: {', '.join(details.get('permissions', []))}\nInherits: {', '.join(details.get('inherits', [])) or 'None'}"
        })

    for u in data["users"]:
        uname = u.get("name", "unknown_user")
        nodes.append({
            "id": f"user:{uname}",
            "label": uname,
            "group": "user",
            "title": f"User: {uname}\nAssigned roles: {', '.join(u.get('roles', []))}"
        })
        for r in u.get("roles", []):
            if r in data["roles"]:
                edges.append({"from": f"user:{uname}", "to": f"role:{r}", "label": "assigned", "arrows": "to"})

    for role, details in data["roles"].items():
        for inherited in details.get("inherits", []):
            if inherited in data["roles"]:
                edges.append({"from": f"role:{role}", "to": f"role:{inherited}", "label": "inherits", "arrows": "to"})

    return {"nodes": nodes, "edges": edges}


@app.route("/", methods=["GET"])
def home():
    data_file = get_current_data_file()
    data = load_data(data_file)
    G = build_role_graph(data)
    mitre_map = load_mitre_map()

    findings = find_escalation_paths(data, G, mitre_map)
    overprivileged = find_overprivileged_users(data, G, mitre_map)
    conflicts = find_conflicts(data, G)

    stats = {
        "total_users": len(data.get("users", [])),
        "total_roles": len(data.get("roles", {})),
        "escalations_found": len(findings),
        "overprivileged_found": len(overprivileged),
        "conflicts_found": len(conflicts),
        "data_file": os.path.basename(data_file),
        "last_loaded": session.get("last_loaded", "default dataset")
    }

    return render_template("index.html", findings=findings, overprivileged=overprivileged, conflicts=conflicts, stats=stats)


@app.route("/upload", methods=["POST"])
def upload():
    if "file" not in request.files:
        flash("No file provided.")
        return redirect(url_for("home"))

    f = request.files["file"]
    if not f.filename:
        flash("No selected file.")
        return redirect(url_for("home"))

    filename = secure_filename(f.filename)
    if not filename.lower().endswith(".json"):
        flash("Please upload a .json file.")
        return redirect(url_for("home"))

    unique_name = f"{uuid.uuid4().hex[:8]}_{filename}"
    save_path = os.path.join(UPLOAD_DIR, unique_name)
    f.save(save_path)

    try:
        data = load_data(save_path)
    except Exception:
        flash("Invalid JSON.")
        return redirect(url_for("home"))

    ok, msg = validate_dataset(data)
    if not ok:
        flash(f"Dataset rejected: {msg}")
        return redirect(url_for("home"))

    session["current_data_file"] = save_path
    session["last_loaded"] = f"{filename} @ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    flash(f"Loaded dataset: {filename}")
    return redirect(url_for("home"))


@app.route("/reset", methods=["POST"])
def reset():
    session.pop("current_data_file", None)
    session["last_loaded"] = "default dataset"
    flash("Reset to default dataset.")
    return redirect(url_for("home"))


@app.route("/graph", methods=["GET"])
def graph():
    data_file = get_current_data_file()
    data = load_data(data_file)
    payload = build_vis_graph_payload(data)
    return render_template("graph.html", graph_payload=json.dumps(payload), data_file=os.path.basename(data_file))


@app.route("/playbook", methods=["GET"])
def playbook():
    return render_template("playbook.html")


if __name__ == "__main__":
    app.run(debug=True)
